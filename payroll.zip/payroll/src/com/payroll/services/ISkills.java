package com.payroll.services;

public interface ISkills {

}
