package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.payroll.exceptions.PayrollException;
import com.payroll.model.Skills;
import com.payroll.util.ConnectionUtil;

public class SkillDAO {

	public SkillDAO() {
		// TODO Auto-generated constructor stub
	}
	public int registerSkill(/*Connection connObj,*/Skills skills)throws PayrollException
	{
		int generatedId=0;
		String query="Insert into emp_skills (skill_name) values(?)";
		Connection connObj=null;
		PreparedStatement pstmt=null;
		//Statement stmt=null;
		ResultSet result=null;
		try{
			connObj=ConnectionUtil.getConnection();
				pstmt=connObj.prepareStatement(query);
				pstmt.setString(1, skills.getSkillName());
				pstmt.executeUpdate();
				result=pstmt.getGeneratedKeys();
				
				if(result.next())
				{
					generatedId=result.getInt(1);
				}
		}
		catch(SQLException e)
		{
			System.out.println(e);
			e.printStackTrace();
			throw new PayrollException("Skill DAO has problem"+e);
		}
		finally
		{
			try{
			if( result!=null )
			{
					result.close();	
			}	
			if( pstmt!=null )
			{
					pstmt.close();	
			}
			if( connObj!=null )
			{
				connObj.close();
			}
			}
			catch(SQLException e)
				{
					throw new PayrollException("Skill DAO has problem"+e);
				}
		}
		return generatedId;
	}
	public List<Skills> fetchAllData()throws PayrollException{
		List<Skills> skills=new ArrayList<Skills>();
		
		//boolean flag=false;
		String query="Select * from skills";
		
		PreparedStatement pstmt=null;
		ResultSet result=null;
		Connection connObj=null;
		try{
			connObj=ConnectionUtil.getConnection();
			
			pstmt=connObj.prepareStatement(query);
			result=pstmt.executeQuery();
			while(result.next()){
				int skillId=result.getInt("skill_id");
				String skillName=result.getString("skill_name");
				
				Skills skill=new Skills(skillId,skillName);
				skill.setSkillId(skillId);
				skill.setSkillName(skillName);
				skills.add(skill);
				
				
				
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
			e.printStackTrace();
			throw new PayrollException("Skill  DAO has problem"+e);
		}
		finally
		{
			try{
			if( result!=null )
			{
					result.close();	
			}	
			if( pstmt!=null )
			{
					pstmt.close();	
			}
			if( connObj!=null )
			{
				connObj.close();
			}
			}
			catch(SQLException e)
				{
					throw new PayrollException("Skill  DAO has problem"+e);
				}
		}
		return skills;
	}
}
