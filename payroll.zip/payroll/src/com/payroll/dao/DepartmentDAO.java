package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.payroll.exceptions.PayrollException;
import com.payroll.model.Department;
import com.payroll.model.Skills;
import com.payroll.util.ConnectionUtil;
public class DepartmentDAO {

	public DepartmentDAO() {
	}
		// TODO Auto-generated constructor stub\
			public int registerDepartment(Connection connObj,Department department)throws PayrollException
					{
				int generatedId=0;
				String query="Insert into department (dept_name,dept_location) values(?,?)";
				//Connection connObj=null;
				PreparedStatement pstmt=null;
				//Statement stmt=null;
				ResultSet result=null;
				try{
					connObj=ConnectionUtil.getConnection();
						pstmt=connObj.prepareStatement(query);
						pstmt.setString(1, department.getDepartmentName());
						pstmt.setString(2, department.getDepartmentLocation());
						pstmt.executeUpdate();
						result=pstmt.getGeneratedKeys();
						
						if(result.next())
						{
							generatedId=result.getInt(1);
						}
				
				}
				catch(SQLException e)
				{
					e.printStackTrace();
					throw new PayrollException("Login DAO has problem"+e);
				}
				finally
				{
					try{
					if( result!=null )
					{
							result.close();	
					}	
					if( pstmt!=null )
					{
							pstmt.close();	
					}
					if( connObj!=null )
					{
						connObj.close();
					}
					}
					catch(SQLException e)
						{
							throw new PayrollException("Login DAO has problem"+e);
						}
				}
				
				return generatedId;
	}
			
			
			
			public  List<Department> fetchAllData()throws PayrollException{
				List<Department> department=new ArrayList<Department>();
				
				//boolean flag=false;
				String query="Select * from department";
				/*String queryByName="Select e.*,ed.*,d.*,"
						+"group_concat(s.skill_name) as skills from "+
						"employee e inner join emp_address ed inner join department d inner join skills s "+
						"inner join emp_skillset sk on ed.address_id=e.fk_address_id "+
						"and e.fk_dept_id=d.dept_id and e.emp_id=sk.fk_emp_id and s.skill_id=fk_skill_id where e.emp_name like "
						+ "? group by e.emp_id";*/
				PreparedStatement pstmt=null;
				ResultSet result=null;
				Connection connObj=null;
				
				try{
					connObj=ConnectionUtil.getConnection();
					
					pstmt=connObj.prepareStatement(query);
					result=pstmt.executeQuery();
					while(result.next()){
						int departmentId=result.getInt("dept_id");
						String departmentName=result.getString("dept_name");
						String departmentLocation=result.getString("dept_location");
						
						Department departments=new Department(departmentId,departmentName,departmentLocation);
						
						department.add(departments);
						
						
						
					}
				}
				catch(SQLException e)
				{
					System.out.println(e);
					e.printStackTrace();
					throw new PayrollException("Skill  DAO has problem"+e);
				}
				finally
				{
					try{
					if( result!=null )
					{
							result.close();	
					}	
					if( pstmt!=null )
					{
							pstmt.close();	
					}
					if( connObj!=null )
					{
						connObj.close();
					}
					}
					catch(SQLException e)
						{
							throw new PayrollException("Skill  DAO has problem"+e);
						}
				}
				return department;
			}
			
		}



